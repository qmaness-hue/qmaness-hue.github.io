#include <xc.h>
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/adc/adc.h"

// Define threshold voltage in ADC counts
#define VREF 5.0              // Adjust to your reference voltage
#define ADC_MAX 1023          // 10-bit ADC
#define THRESHOLD_VOLTAGE 0.8 // 1V threshold
#define THRESHOLD_COUNT ((uint16_t)((THRESHOLD_VOLTAGE / VREF) * ADC_MAX))

void main(void)
{
    // Initialize the device
    SYSTEM_Initialize();
    
    // Initialize ADC
    ADC_Initialize();
    
    while (1)
    {
        // Select RC5 channel and start conversion
        ADC_ChannelSelect(RC5);
        ADC_ConversionStart();
        
        // Wait for conversion to complete
        while(!ADC_IsConversionDone());
        
        // Get ADC result
        uint16_t adcValue = ADC_ConversionResultGet();
        
        if(adcValue <= THRESHOLD_COUNT)
        {
            // Voltage <= 1V: LED ON, RA1 HIGH
            LED_SetHigh();    // Assuming RB3 is LED
            RA1_SetHigh();    // Output indicator
        }
        else
        {
            // Voltage > 1V: LED OFF, RA1 LOW
            LED_SetLow();     // Assuming RB3 is LED
            RA1_SetLow();     // Output indicator
        }
    }
}